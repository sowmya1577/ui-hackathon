# 🎮 Pixel Quest - Retro Pixel Art Platformer

A fully interactive, browser-based retro-style pixel art platformer game with collectible items, smooth character movement, and mobile-friendly controls. This project uses HTML, CSS (Tailwind), and JavaScript—perfect for nostalgic gaming enthusiasts and developers alike!

## 🌟 Features

- **Responsive Layout** with Tailwind CSS
- **Pixel Art Design** for player, background, platforms, and collectibles
- **Realistic Platforms** with drop shadows and hover effects
- **Inventory System** that updates live as you collect:
  - 💰 Coins
  - 💎 Gems
  - 💖 Hearts
  - 🔑 Keys
  - 🧪 Potions
- **Touch Controls** for mobile compatibility
- **Keyboard Controls** for desktop:
  - `← / A` – Move Left
  - `→ / D` – Move Right
  - `↑ / W / Space` – Jump

## 📁 Project Structure

```
.
├── index.html      # Main HTML file containing all game logic and UI
```

## 🚀 Getting Started

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/pixel-quest.git
   cd pixel-quest
   ```

2. Open `index.html` in any modern browser to start playing.

> No build tools or setup required!

## 📸 Preview

![Screenshot](https://storage.googleapis.com/a1aa/image/127b9f3b-d27f-41e5-a88d-31a0c7d63fec.jpg)

## 🛠 Technologies Used

- HTML5
- Tailwind CSS
- Vanilla JavaScript
- Font Awesome
- Google Fonts (Press Start 2P)

## 🎯 Future Improvements

- Add more levels
- Implement enemies and health system
- Integrate sound effects and background music
- Save/load progress via local storage

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

---

Made with ❤️ for retro gaming by [Your Name]
